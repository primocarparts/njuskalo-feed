PRIMO NJUSKALO - DAILY STOCK SYNC

Brez BAT-a in brez prizganega racunalnika. GitHub Actions 1x dnevno:
- doda nove ACTIVE ECU SKU z inventory > 0
- odstrani SKU, ki imajo stock 0 ali niso vec ACTIVE ECU
- obstojecih oglasov ne spreminja
- ce ni sprememb, ne naredi commita

V repo primocarparts/njuskalo-feed nalozi:
1) PrimoNjusaklo_DAILY_STOCK_SYNC.py v root
2) .github/workflows/njuskalo-daily-stock-sync.yml
3) obstojeci njuskalo.xml ostane v rootu

GitHub -> Settings -> Secrets and variables -> Actions:
SHOPIFY_CLIENT_ID
SHOPIFY_CLIENT_SECRET

Workflow tece 1x dnevno ob 02:15 UTC in ga lahko rocno testiras z Run workflow.
Shopify se NE spreminja; program ga samo bere.
Pred produkcijskim REMOVE naj Njusaklo potrdi, da izginotje original_id iz feeda deaktivira/odstrani oglas.
